package controller;

import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;

import java.util.Arrays;

public class ContactBarController {
    public Text txtName;
    private static String port;
    public void setData(String name,String port){
        System.out.println(name);
        System.out.println(port);
        txtName.setText(name);
        String[] split = port.split("User");
        System.out.println(Arrays.toString(split));
        ContactBarController.port=split[1];
        System.out.println(ContactBarController.port);
    }

    public void contactClickOnMouseClick(MouseEvent mouseEvent) {
        DashboardController.port=ContactBarController.port;
        DashboardController.getInstance().txtName.setText(txtName.getText());
        DashboardController.getInstance().vBox.getChildren().clear();
        DashboardController.getInstance().txtUId.setText("User"+port);
    }
}
