package controller;

import com.jfoenix.controls.JFXTextField;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.HPos;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.stage.Window;
import sample.BarController;
import util.Navigation;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class DashboardController implements Initializable {

    public static String port;
    private static DashboardController dashboardController;
    public VBox contactVbox;
    public Text txtName;
    public VBox vBox;
    public JFXTextField txtMessage;
    public Text txtUId;
    private String checkMessage;

    Socket socket;
    DataInputStream dataInputStream;
    DataOutputStream dataOutputStream;
    String message = "";

    public static ArrayList<String[]> contactList=new ArrayList<>();

    public DashboardController() {
        dashboardController = this;
    }

    public static DashboardController getInstance() {
        return dashboardController;
    }

    public void addNewContactOnAction(ActionEvent actionEvent) {
        try {
            Navigation.popupNavigation("AddNewContact.fxml");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void OkOnAction(ActionEvent actionEvent) throws IOException {

        Label text = new Label();
        text.setText("   " + txtMessage.getText() + "   ");
        text.setStyle("    -fx-shape: \"M 800 100 Q 750 100 750 150 L 50 150 Q 0 100 50 50 Q 400 50 750 50 Z\";\n" +
                "    -fx-background-color: #7190e0;\n" +
                "    -fx-font-family: \"fantasy\";\n" +
                "    -fx-font-size: 15; -fx-padding: 10; -fx-start-margin: 200 ; -fx-text-fill: #fff");
        text.setMinWidth(200);
        final Group root = new Group();

        final GridPane gridpane = new GridPane();
        gridpane.setPadding(new Insets(5));
        gridpane.setHgap(10);
        gridpane.setVgap(10);
        gridpane.minHeight(30);
        text.maxHeight(200);
        gridpane.maxHeight(200);


        GridPane.setHalignment(text, HPos.CENTER);
        gridpane.add(text, 0, 0);
        gridpane.setAlignment(Pos.CENTER_RIGHT);

        root.getChildren().add(gridpane);

        vBox.getChildren().add(gridpane);

        //=================================== action =========================================




        //========================================================================================
        dataOutputStream.writeUTF(port);
        dataOutputStream.flush();
        dataOutputStream.writeUTF(txtMessage.getText());
        checkMessage=txtMessage.getText();
        dataOutputStream.flush();
        txtMessage.setText("");
    }

    public void sendInFo(String port,String info){
        try {
            dataOutputStream.writeUTF(port);
            dataOutputStream.flush();
            dataOutputStream.writeUTF(info);
            dataOutputStream.flush();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        new Thread(() -> {
            try {
                socket = new Socket("localhost", 3000);
                System.out.println("socket.getLocalPort() > " + socket.getLocalPort());
                dataInputStream = new DataInputStream(socket.getInputStream());
                dataOutputStream = new DataOutputStream(socket.getOutputStream());

                while (!message.equals("Finish")) {
                    message = dataInputStream.readUTF();
                    System.out.println(">" + message);

                    if (message.startsWith("chitChat://30000:")){

                        Label text = new Label();
                        text.setText(message);
                        text.setStyle("    -fx-shape: \"M 800 100 Q 750 100 750 150 L 50 150 Q 0 100 50 50 Q 400 50 750 50 Z\";\n" +
                                "    -fx-background-color: #CB97FF;\n" +
                                "    -fx-font-family: \"fantasy\";\n" +
                                "    -fx-font-size: 15; -fx-padding: 10; -fx-start-margin: 200 ; -fx-text-fill: #fff");
                        text.setMinWidth(200);
                        final Group root = new Group();


                        final GridPane gridpane = new GridPane();
                        gridpane.setPadding(new Insets(5));
                        gridpane.setHgap(0);
                        gridpane.setVgap(1);
                        gridpane.minHeight(30);
                        text.maxHeight(200);
                        gridpane.maxHeight(200);

                        //==============================================================
                        Button button=new Button();
                        button.setAlignment(Pos.CENTER);
                        button.setMinWidth(200);
                        button.setStyle("" +
                                "-fx-background-radius: 100;" +
                                "-fx-background-color: transparent;" +
                                "-fx-background-image: url(/view/assest/image/share.png);  " +
                                "-fx-background-repeat: stretch;\n" +
                                "    -fx-background-size: 13 13;\n" +
                                "    -fx-background-position: left;" +
                                "" +
                                ""

                        );


                        button.setOnAction(actionEvent -> {
                           // System.out.println(" <<<< new >>>>");
                            try {
                                FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/GroupBar.fxml"));
                                Parent barPane = loader.load();
                                GroupBarController controller = loader.getController();
                                controller.setData(AddNewGroupController.getInstance().txtName.getText(),"User"+socket.getLocalPort());
                                Platform.runLater(() -> {
                                    DashboardController.getInstance().contactVbox.getChildren().add(barPane);
                                });
                            } catch (IOException e) {
                                e.printStackTrace();
                            }

                            DashboardController.port= String.valueOf(socket.getLocalPort());
                            DashboardController.getInstance().txtName.setText("Group");
                            DashboardController.getInstance().vBox.getChildren().clear();
                            DashboardController.getInstance().txtUId.setText("User"+socket.getLocalPort());


                        });

                        //==============================================================


                        GridPane.setHalignment(text, HPos.CENTER);
                        GridPane.setHalignment(button, HPos.RIGHT);
                        gridpane.add(text, 0, 0);
                        gridpane.add(button, 0, 0);
                        gridpane.setAlignment(Pos.CENTER_RIGHT);

                        root.getChildren().add(gridpane);

                        DashboardController.getInstance().vBox.getChildren().add(gridpane);


                    }else if (message.endsWith(".jpg")|message.endsWith(".png")){
                        Platform.runLater(() -> {

                            String[] split = message.split("Image ");

                            System.out.println(split[1]);
                            Image image1 = new Image(split[1], 360, 720, true, true);
                            ImageView image = new ImageView(image1);
                            final Group root = new Group();

                            final GridPane gridpane = new GridPane();
                            gridpane.setPadding(new Insets(5));
                            gridpane.setHgap(10);
                            gridpane.setVgap(10);
                            gridpane.minHeight(30);
                            gridpane.maxHeight(200);


                            GridPane.setHalignment(image, HPos.CENTER);
                            gridpane.add(image, 0, 0);
                            gridpane.setAlignment(Pos.CENTER_LEFT);

                            root.getChildren().add(gridpane);

                            vBox.getChildren().add(gridpane);


                        });

                    }else {
                        Platform.runLater(() -> {

                            if(!checkMessage.equals(message)){
                                checkMessage=null;
                                Label text = new Label();
                                text.setText("   " + message + "   ");
                                text.setStyle("    -fx-shape:  \"M 750 50 Q 800 100 750 150 L 50 150 Q 50 100 0 100 Q 50 50 50 50 Z\";\n" +
                                        "    -fx-background-color: #7190e0;\n" +
                                        "    -fx-font-family: \"fantasy\";\n" +
                                        "    -fx-font-size: 15; -fx-padding: 10; -fx-start-margin: 200 ; -fx-text-fill: #fff");
                                text.setMinWidth(200);
                                final Group root = new Group();

                                final GridPane gridpane = new GridPane();
                                gridpane.setPadding(new Insets(5));
                                gridpane.setHgap(10);
                                gridpane.setVgap(10);
                                gridpane.minHeight(30);
                                text.maxHeight(200);
                                gridpane.maxHeight(200);
                                GridPane.setHalignment(text, HPos.CENTER);
                                gridpane.add(text, 0, 0);
                                gridpane.setAlignment(Pos.CENTER_LEFT);

                                root.getChildren().add(gridpane);

                                vBox.getChildren().add(gridpane);
                            }



                        });
                    }

                }


            } catch (IOException e) {
                throw new RuntimeException(e);
            }

            Platform.runLater(() -> {

            });

        }).start();
    }

    public void BrowsImageOnAction(ActionEvent actionEvent) {
        FileChooser chooser = new FileChooser();
        File file = chooser.showOpenDialog(new Stage());
        if (file != null) {

            System.out.println(file.getPath());
            Image image1 = new Image(file.getPath(), 360, 720, true, true);
            ImageView image = new ImageView(image1);
            final Group root = new Group();

            final GridPane gridpane = new GridPane();
            gridpane.setPadding(new Insets(5));
            gridpane.setHgap(10);
            gridpane.setVgap(10);
            gridpane.minHeight(30);
            gridpane.maxHeight(200);


            GridPane.setHalignment(image, HPos.CENTER);
            gridpane.add(image, 0, 0);
            gridpane.setAlignment(Pos.CENTER_RIGHT);

            root.getChildren().add(gridpane);

            vBox.getChildren().add(gridpane);


//           ===============================================================
            try {
                dataOutputStream.writeUTF(port);
                dataOutputStream.flush();
                dataOutputStream.writeUTF("Image "+file.getPath());
                dataOutputStream.flush();
            } catch (IOException e) {
                e.printStackTrace();
            }


        }
    }

    public void addNewGroupOnAction(ActionEvent actionEvent) {
        try {
            Navigation.popupNavigation("AddNewGroup.fxml");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

